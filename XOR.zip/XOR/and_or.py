import random

# Función de activación (Heaviside step function)
def step_function(x):
    return 1 if x >= 0 else -1

# Función AND
inputs = [
    [1, 1, 1],  # X0, X1, X2 (X0 es el bias)
    [1, 1, -1],
    [1, -1, 1],
    [1, -1, -1]
]

desired_outputs = [1, -1, -1, -1]  # Salidas AND 1, -1, -1, -1
#desired_outputs = [1, 1, 1, -1]  # Salidas OR
#desired_outputs = [-1, 1, 1, -1]  # Salidas XOR

# Pesos aleatorios
w0 = random.uniform(0, 1)
w1 = random.uniform(0, 1)
w2 = random.uniform(0, 1)
weights = [w0, w1, w2]

# Tasa de aprendizaje
alpha = 0.4

# Iteraciones
iterations = 10 

print("Pesos iniciales:", weights)

for epoch in range(iterations):
    total_error = 0
    for i in range(len(inputs)):
        x = inputs[i]
        y_d = desired_outputs[i]
        y = step_function(sum(w * xi for w, xi in zip(weights, x)))  # Perceptrón
        error = y_d - y
        total_error += abs(error)
        
        # Actualización de pesos
        for j in range(len(weights)):
            weights[j] += alpha * error * x[j]

        # Imprimir detalles de la iteración
        print(f"Iteración {epoch+1}, Entrada: {x}, Salida esperada: {y_d}, Salida obtenida: {y}, Error: {error}, Pesos: {weights}")

    # Impresion del error
    print(f"Epoch {epoch+1}, Error total: {total_error}\n")
    if total_error == 0:
        break

print("Pesos finales:", weights)