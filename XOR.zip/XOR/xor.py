
import random
import math

# Función de activación sigmoide
def sigmoid(x):
    return 1 / (1 + math.exp(-x))

# Derivada de la función sigmoide
def sigmoid_derivative(x):
    return x * (1 - x)

# Inicialización de pesos y biases con valores aleatorios
def initialize_weights(input_neurons, hidden_neurons, output_neurons):
    hidden_weights = [[random.uniform(-1, 1) for _ in range(hidden_neurons)] for _ in range(input_neurons)]
    hidden_bias = [random.uniform(-1, 1) for _ in range(hidden_neurons)]
    output_weights = [[random.uniform(-1, 1) for _ in range(output_neurons)] for _ in range(hidden_neurons)]
    output_bias = [random.uniform(-1, 1) for _ in range(output_neurons)]
    return hidden_weights, hidden_bias, output_weights, output_bias

# Propagación hacia adelante
def forward_propagate(inputs, hidden_weights, hidden_bias, output_weights, output_bias):
    hidden_layer_activation = [0] * len(hidden_weights[0])
    for i in range(len(inputs)):
        for j in range(len(hidden_layer_activation)):
            hidden_layer_activation[j] += inputs[i] * hidden_weights[i][j]
            
    hidden_layer_output = [sigmoid(x + hidden_bias[i]) for i, x in enumerate(hidden_layer_activation)]
    
    output_layer_activation = [0] * len(output_weights[0])
    for i in range(len(hidden_layer_output)):
        for j in range(len(output_layer_activation)):
            output_layer_activation[j] += hidden_layer_output[i] * output_weights[i][j]
    predicted_output = [sigmoid(x + output_bias[i]) for i, x in enumerate(output_layer_activation)]
    
    return hidden_layer_output, predicted_output

# Retropropagación
def back_propagate(inputs, hidden_layer_output, predicted_output, desired_output, hidden_weights, hidden_bias, output_weights, output_bias, alpha):
    output_errors = [desired_output[i] - predicted_output[i] for i in range(len(desired_output))]
    d_predicted_output = [output_errors[i] * sigmoid_derivative(predicted_output[i]) for i in range(len(output_errors))]
    
    hidden_errors = [0] * len(hidden_layer_output)
    for i in range(len(hidden_errors)):
        for j in range(len(d_predicted_output)):
            hidden_errors[i] += d_predicted_output[j] * output_weights[i][j]
    d_hidden_layer = [hidden_errors[i] * sigmoid_derivative(hidden_layer_output[i]) for i in range(len(hidden_errors))]
    
    # Actualización de los pesos y los biases
    for i in range(len(hidden_weights)):
        for j in range(len(hidden_weights[i])):
            hidden_weights[i][j] += alpha * d_hidden_layer[j] * inputs[i]
    for i in range(len(hidden_bias)):
        hidden_bias[i] += alpha * d_hidden_layer[i]
    
    for i in range(len(output_weights)):
        for j in range(len(output_weights[i])):
            output_weights[i][j] += alpha * d_predicted_output[j] * hidden_layer_output[i]
    for i in range(len(output_bias)):
        output_bias[i] += alpha * d_predicted_output[i]
    
    return hidden_weights, hidden_bias, output_weights, output_bias

# Datos de entrada y salidas deseadas para la función AND
and_inputs = [
    [1, 1, 1],  # X0 (bias), X1, X2
    [1, 1, -1],
    [1, -1, 1],
    [1, -1, -1]
]
and_desired_outputs = [1, -1, -1, -1]  # Salidas deseadas

# Pesos iniciales aleatorios para AND
and_weights = [random.uniform(0, 1) for _ in range(3)]
alpha_and = 0.4
iterations_and = 10

print("Entrenando la compuerta AND...")
for epoch in range(iterations_and):
    total_error = 0
    for i in range(len(and_inputs)):
        x = and_inputs[i]
        y_d = and_desired_outputs[i]
        y = 1 if sum(w * xi for w, xi in zip(and_weights, x)) >= 0 else -1  # Salida del perceptrón
        error = y_d - y
        total_error += abs(error)
        
        # Actualización de pesos
        for j in range(len(and_weights)):
            and_weights[j] += alpha_and * error * x[j]

        print(f"Iteración {epoch+1}, Entrada: {x}, Salida esperada: {y_d}, Salida obtenida: {y}, Error: {error}, Pesos: {and_weights}")

    print(f"Epoch {epoch+1}, Error total: {total_error}\n")
    if total_error == 0:
        break

print("Pesos finales AND:", and_weights)

# Datos de entrada y salidas deseadas para la función XOR
xor_inputs = [
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
]
xor_desired_outputs = [
    [0],
    [1],
    [1],
    [0]
]

# Inicialización para XOR
input_neurons = len(xor_inputs[0])
hidden_neurons = 2
output_neurons = 1
hidden_weights, hidden_bias, output_weights, output_bias = initialize_weights(input_neurons, hidden_neurons, output_neurons)

alpha_xor = 0.5

print("Entrenando la compuerta XOR...")

epoch = 0
while True:
    total_error = 0
    for i in range(len(xor_inputs)):
        hidden_layer_output, predicted_output = forward_propagate(xor_inputs[i], hidden_weights, hidden_bias, output_weights, output_bias)
        hidden_weights, hidden_bias, output_weights, output_bias = back_propagate(xor_inputs[i], hidden_layer_output, predicted_output, xor_desired_outputs[i], hidden_weights, hidden_bias, output_weights, output_bias, alpha_xor)
        total_error += sum([(xor_desired_outputs[i][j] - predicted_output[j]) ** 2 for j in range(len(xor_desired_outputs[i]))])
    
    epoch += 1
    if epoch % 1000 == 0:
        print(f"Epoch {epoch}, Error: {total_error / len(xor_inputs)}")
    
    user_input = input("Presiona 'q' para detener el entrenamiento o cualquier otra tecla para continuar: ")
    if user_input.lower() == 'q':
        break

# Resultados finales XOR
print("Pesos finales de la capa oculta XOR:\n", hidden_weights)
print("Bias final de la capa oculta XOR:\n", hidden_bias)
print("Pesos finales de la capa de salida XOR:\n", output_weights)
print("Bias final de la capa de salida XOR:\n", output_bias)

# Prueba final de XOR después del entrenamiento
print("Prueba de XOR después del entrenamiento:")
for i in range(len(xor_inputs)):
    _, predicted_output = forward_propagate(xor_inputs[i], hidden_weights, hidden_bias, output_weights, output_bias)
    print(f"Entrada: {xor_inputs[i]}, Salida esperada: {xor_desired_outputs[i]}, Salida obtenida: {[round(x) for x in predicted_output]}")